# JAICKNX para iOS — proyecto listo para compilar sin firma

Este proyecto envuelve la web original en una app iOS mediante WKWebView. La interfaz, estilos y JavaScript se conservan en `JAICKNX/Assets/index.html`; no necesita conexión a Internet para cargar.

## Crear una IPA sin firmar (requiere Mac con Xcode)

1. Descomprime este ZIP en un Mac.
2. Abre `JAICKNX.xcodeproj` con Xcode.
3. Selecciona el destino **Any iOS Device (arm64)**.
4. En **Signing & Capabilities**, deja desactivada la gestión automática de firma (el proyecto ya está configurado con `CODE_SIGNING_ALLOWED=NO`).
5. Para compilar desde Terminal, desde esta carpeta ejecuta:

```bash
xcodebuild -project JAICKNX.xcodeproj -scheme JAICKNX -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
```

6. Empaqueta el `.app` dentro de `Payload` y crea la IPA:

```bash
mkdir -p Payload
cp -R build/Build/Products/Release-iphoneos/JAICKNX.app Payload/
zip -r JAICKNX-unsigned.ipa Payload
rm -rf Payload
```

El archivo `JAICKNX-unsigned.ipa` quedará en la carpeta actual.

## Importante sobre una IPA sin firmar

Una IPA sin firma es un paquete de instalación, no una app que iOS permita instalar normalmente. No se instala tocándola desde Archivos ni con TestFlight. Para ejecutarla en un iPhone se necesita firmarla con un certificado válido o usar un método compatible de instalación/sideloading; la compatibilidad depende de la versión de iOS y del dispositivo. Este proyecto no incluye certificados ni perfiles de firma.

## Acceso de demostración que ya trae la web

- Usuario: `JaickNX`
- Contraseña: `JaickFF04`

## Alcance funcional

La web original presenta controles visuales y un panel de demostración. Sus interruptores no se conectan a Free Fire ni modifican el juego. El login está implementado en el HTML del lado del cliente, por lo que no debe considerarse autenticación segura para proteger datos reales.
